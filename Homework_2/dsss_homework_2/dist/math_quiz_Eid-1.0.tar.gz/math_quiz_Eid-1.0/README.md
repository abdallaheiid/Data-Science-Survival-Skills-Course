# dsss_homework_2
Data science survival skills Homework 2
